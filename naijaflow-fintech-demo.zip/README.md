# NaijaFlow Fintech Demo
A responsive Nigerian fintech app prototype featuring a simulated wallet, transfers, airtime and bills, savings goals, and transaction history/CSV export.

## Run
Open `index.html` in a modern browser.

## Publish with GitHub Pages
Upload `index.html` to the root of your GitHub repository. In Settings → Pages, choose Deploy from a branch, select `main` and `/ (root)`.

## Safety
This is a demo only. It does not connect to banks or payment providers and does not move real money. Do not enter real banking credentials or sensitive personal data.
